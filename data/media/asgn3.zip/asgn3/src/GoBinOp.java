public enum GoBinOp
{
	OR
}