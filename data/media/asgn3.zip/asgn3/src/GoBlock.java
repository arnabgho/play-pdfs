import java.io.*;
import java.util.*;
public class GoBlock
{
	
	public void gen()
	{
		System.out.println("Inside GoBlock");
	}
}