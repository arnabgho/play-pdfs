package main;
// import "fmt";
func main(){

    var i int;
    var p int;
    //p = &i;
    p = p+2+p+23.78;

    // if 12 == 45 {
    //     i = 6;
    //     i = i+5;
    // };
};  // don't dare to remove th*/*/e semicolon !!!!!!!!!!
