package main; 
// import "fmt"; 
func swap(x, y int) (zdgcffhgh int)
{ 
	var z int;
	return z; 
};

func main()
{ 
	var i, j int = +2, 9;
	j = swap(i, j);

};