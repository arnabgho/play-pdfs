package main;
import "fmt";

/*func Tnirp(val int) int {
    println(val);
    return 0;
};*/


func main(){
    // var a int;
    
    var i 23;
    i = i+2;


    /*var p *int;
    p = &i;
    *p = 21;*/

    /*if 12 == 45 {
        i = 5;
        i = a+5;
    };*/
    /*if i = 13; 12 == 45 {       // If with a short statement
        i = 5;
        i = a+5;
    };*/
    /*if i = 2; i < 12 {
        i = 67;
    } else {
        i = 34;
    };*/

    /*if i = 2; i < 12 {
        i = 67;
        i = i + 67;
    } else {
    };*/

    //for {};
    //for ; i < 19; { i = i+1; };
    //for i < 45 { i = i+1; };       // go's while loop
    //for i = 45; i < 19; i = i+3 { i = i+1; };

    /*for i = 45; i < 19; i++ { 
        i = i+1; 
        i = 343; 
        i = i*(i+2);
    };*/
    /*for sum == 1000 {
        sum = 1; 
    };*/ 

    //return 0;

    /*for sum == 1000 {
        sum = 1; 
        if sum == 2 { 
            sum = sum + 12;
            continue; 
        } else {
            goto Here;
        };
    };
    Here: 
    println(sum);*/
    

    /*i = i+(z/45*12^i-(12));
    const v int = 3;
    var os, ys float64 = 2, 4;*/

    /*var a [2]string;
    a[0] = "Hello";
    a[1] = "World";*/

    //var p = []int{2, 3, 5, 7, 11, 13};        // slice
    // var p = [6]int{2, 3, 5, 7, 11, 13};      // array

    //i++;


    //a = wraaaa();
    // fmt.Println(i);
    // i = Tnirp(100);


    /*switch i {
    case 23:
        i = 9;
    case 78:
        i = 66;
        break;
    default:
        // freebsd, openbsd,
        // plan9, windows...
        i = -9;
    }*/
    
};  // don't dare to remove the semicolon !!!!!!!!!!
