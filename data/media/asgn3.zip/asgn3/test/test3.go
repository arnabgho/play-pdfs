package main;
import "fmt";

func main(){

    var i int;
 
    if i = 2; i < 12 {
       i = 67;
    } else {
        i = 34;
    };

    if i = 2; i < 12 {
        i = 67;
        i = i + 67;
    } else {
    };

};  // don't dare to remove the semicolon !!!!!!!!!!
