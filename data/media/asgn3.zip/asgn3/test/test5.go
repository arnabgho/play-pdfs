package main;
import "fmt";

func main(){
    var i int;
     if i == i+1 { i++; break; };


    for i < 45 { i = i+1; break; };       // go's while loop
    
    for i = 45; i < 19; i = i+3 { i = i+1; };

    for i = 45; i < 19; i++ { 
        i = i+1; 
        i = 343; 
        i = i*(i+2);
    };
    
    for {};
}; 