package main;
import "fmt";

func main(){
	var os, a, x int;
    Printf("%s.", os);
   switch os=3; {
	
	case 1: a=7;
    case 2: Printf("%s.", os);
    default: Printf("%s.", os);
	/*	freebsd, openbsd,
		plan9, windows...*/
		//Printf("%s.", os);
	};

	switch os<3 {
	case 1: a=7;
	case 2: Printf("%s.", os);
    default: Printf("%s.", os);
};
	/*	freebsd, openbsd,
	//default:
		// freebsd, openbsd,
		// plan9, windows...
	//	Printf("%s.", os);
	};*/

	switch os=3;x<4 {
	case 1: a=7;
	case 2: Printf("%s.", os);
    default: Printf("%s.", os);
	//default:
		// freebsd, openbsd,
		// plan9, windows...
	//	Printf("%s.", os);
	};


	switch  {
	case 1: a=7;
	case 2: Printf("%s.", os);
    default: Printf("%s.", os);
	//default:
		// freebsd, openbsd,
		// plan9, windows...
	//	Printf("%s.", os);
	};
};
