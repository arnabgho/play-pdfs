package main;
import "fmt";
func main(){ 
    var ( i, j, k int = +1, -3; n, m string = "Vase", "Pane"; );
};