package main;
import "fmt";

// func Tnirp(val string) int {
//     println(val);
//     return 0;
// };


func main(){ 
    var v string = "true";
    // var i int = v;

    var z int;
    var k = [2] int{2, 78};
    var j = [1] string{"sdf"};
    var i int;

    k[i+1] = 89;
    i[k] = "sd";

    var a  = [2] int{3, v};
    var i int;
    
    i = (3*8+1);
    here: there: 
    i = 7*(8+9);
    i = 1||2&&3;
    i = 1*2+3*4/5&&6||7^8;
    Tnirp("String");
    fmt.Println(i);
    return;

    i = println("sdf", 3345, "w");
    i, i, i, z = hello();
      // go's while loop

    here:
    for ;i < 0; i-- 
    { 

            for j = 0;j < 0; j-- {
            
            j++;
            continue here;
            };
        i = i+6;         
    };

    i = 78;
    goto hrere;
    i = 0;
    for i = 45; i < 19; i = i+3 { i = i+1; };
    for ; ; { i = i+1; };

    for i = 45; i < 19; i++ { 
        i = i+1; 
        i = 343; 
        i = i*(i+2);
    };
    for { k =34;};



    if i = 4; i < 1
    {
    	// if i == 2
    	// {
    	// 	i = 3;
    	// }
    	// else
    	// {
    	// 	i = 4;
    	// };
    	// i = 5;
    }
	else if i[i+45], k = 6878, 78; i > 6
	{
		i--;
	}
	else if i > 6
	{
    	i = i*7;
    };

    if i = 2; i < 12 {
       i = 67;
    } else {
        i = 34;
    };

    if i = 2; i < 12 {
        i = 67;
        i = i + 67;
    } else {
    };

};

 

