package main;
import "fmt";

func main(){
    var i, sum int = 12, 1000;
    
    for sum == 1000 {
            sum = 1; 
        }; 

    for sum == 1000 {
        sum = 1; 
        if sum == 2 { 
            sum = sum + 12;
            continue; 
        } else {
            goto Here;
        };
    };
    println(i);
    Here: 
    println(sum);
    
}; 
