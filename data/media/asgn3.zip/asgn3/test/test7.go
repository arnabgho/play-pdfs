package main;
import "fmt";

func main(){
    var i, z int = 12, 0;
    
    i = i+(z/45*12^i-(12));
    const v int = 3;
    var os, ys float64 = 2, 4;

    var a [2]string;
    a[0] = "Hello";
    a[1] = "World";

    //var p = []int{2, 3, 5, 7, 11, 13};        // slice
    //var p = [6]int{2, 3, 5, 7, 11, 13};      // array

    i++;
  
}; 